let input=3;
let lb=require('./A3_2_lib')
let output=lb.f1(input);

console.log(output);