exports.f1=function previousNum(n){

    return --n;
}