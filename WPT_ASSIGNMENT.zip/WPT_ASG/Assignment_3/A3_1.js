function previousNum(n){

    return --n;
}


let input=0;
let output=previousNum(input);

console.log(output);